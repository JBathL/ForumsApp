package com.example.groupf9_inclass08;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Date;


public class CommentFragment extends Fragment {
    final String TAG = "demo";
    ArrayList<Comment> commentList = new ArrayList<>();
    CommentsRecyclerViewAdapter adapter = new CommentsRecyclerViewAdapter(commentList);
    EditText editTextComment;
    TextView tv_ForumTitle, tv_ForumName, tv_ForumDesc, commentNumberTV;
    private FirebaseAuth mAuth;
    private static final String ARG_ID = "ARG_ID";
    String id;


    public CommentFragment() {
        // Required empty public constructor
    }

    public static CommentFragment newInstance(String id) {
        CommentFragment fragment = new CommentFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_ID, id);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            id = (String)getArguments().getSerializable(ARG_ID);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_comment, container, false);

        editTextComment = view.findViewById(R.id.editTextComment);
        tv_ForumTitle = view.findViewById(R.id.tv_ForumTitle);
        tv_ForumName = view.findViewById(R.id.tv_ForumName);
        tv_ForumDesc = view.findViewById(R.id. tv_ForumDesc);
        commentNumberTV = view.findViewById(R.id.commentNumberTV);




        view.findViewById(R.id.btn_commentPost).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String postedComment = editTextComment.getText().toString();

                //alert if comment empty
                if (postedComment.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setTitle("Comment is empty")
                            .setMessage("Please enter your comment")
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which){

                                }
                            });
                    builder.create().show();
                } else {
                    createComment();
                    Toast.makeText(getContext(), "Comment Posted", Toast.LENGTH_SHORT).show();
                }
            }
        });

        getForum();
        //get forum data
        FirebaseFirestore db = FirebaseFirestore.getInstance();


                        //get comments
                        db.collection("ForumsN")
                                .document(id)
                                .collection("Comments").get()
                                .addOnCompleteListener(getActivity(), new OnCompleteListener<QuerySnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                        if (task.isSuccessful()) {
                                            if (task.getResult().size() > 0) {
                                               // commentList.clear();
                                                for (QueryDocumentSnapshot document : task.getResult()) {
                                                    Comment comment = document.toObject(Comment.class);
                                                    commentList.add(comment);
                                                }
                                            } else {
                                                Toast.makeText(getContext(), "There are no comments at this time", Toast.LENGTH_LONG).show();
                                            }

                                            //set up recyclerview
                                            getActivity().runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    RecyclerView recyclerView = view.findViewById(R.id.recyclerViewComments);
                                                    LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
                                                    recyclerView.setLayoutManager(layoutManager);
                                                    recyclerView.setHasFixedSize(true);
                                                    CommentsRecyclerViewAdapter adapter = new CommentsRecyclerViewAdapter(commentList);
                                                    recyclerView.setAdapter(adapter);
                                                    if (commentList.size() == 1) {
                                                        commentNumberTV.setText(String.valueOf(commentList.size()) + " comment");
                                                    } else {
                                                        commentNumberTV.setText(String.valueOf(commentList.size()) + " comments");
                                                    }
                                                    adapter.notifyDataSetChanged();
                                                }
                                            });

                                        }
                                    }
                                });

        return view;
    } //end onCreateView


    @Override
    public void onStart() {
        super.onStart();
        getActivity().setTitle(R.string.title_Forum);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
    }

    public void createComment(){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        Comment comment = new Comment();
        comment.setcText(editTextComment.getText().toString());
        comment.setDate(new Date());
        comment.setName(user.getDisplayName());
        comment.setuId(user.getUid());

        db.collection("ForumsN")
                .document(id)
                .collection("Comments")
                .add(comment)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>(){
                    @Override
                    public void onSuccess(DocumentReference documentReference){
                        commentList.add(comment);
                        adapter.notifyDataSetChanged();

                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if(commentList.size() == 1){
                                    commentNumberTV.setText(String.valueOf(commentList.size()) + " comment");
                                } else {
                                    commentNumberTV.setText(String.valueOf(commentList.size()) + " comments");
                                }


                            }
                        });
                    }

                });
    }



public void getForum(){
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    db.collection("ForumsN")
            .document(id).get()
            .addOnCompleteListener(getActivity(), new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();

                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Log.d(TAG, "run: " + id);
                                        tv_ForumDesc.setText(document.getString("post"));
                                        tv_ForumTitle.setText(document.getString("forumTitle"));
                                        tv_ForumName.setText(document.getString("name"));
                                } //end run
                            });
                        }
                    }
                });
            }

    private void delete(Comment comment){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("ForumsN")
                .document(id)
                .collection("Comments")
                .document(comment.getDocId())
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        adapter.notifyDataSetChanged();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });

    }

    public class CommentsRecyclerViewAdapter extends RecyclerView.Adapter<CommentsRecyclerViewAdapter.MyViewHolder> {
        ArrayList<Comment> comments;
        FirebaseAuth mAuth2 = FirebaseAuth.getInstance();
        FirebaseUser fbUser = mAuth2.getCurrentUser();
        String fbUserString = fbUser.getUid();

        public CommentsRecyclerViewAdapter(ArrayList<Comment> comments) {
            this.comments = comments;
        }

        @NonNull
        @Override
        public CommentsRecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_comment, parent, false);
            MyViewHolder holder = new MyViewHolder(view);
            return holder;
        }

        @Override
        public void onBindViewHolder(@NonNull CommentsRecyclerViewAdapter.MyViewHolder holder, int position) {
            Comment comment = comments.get(position);
            holder.tv_CommentName.setText(comment.getName());
            holder.tv_CommentDesc.setText(comment.getcText());
            holder.tv_CommentDate.setText(String.valueOf(comment.getDate()));

            //get unique value of user id
            if (fbUser.getUid().equals(comment.getuId())) {
                holder.iv_Trash2.setVisibility(View.VISIBLE);
            } else {
                holder.iv_Trash2.setVisibility(View.INVISIBLE);
            }

            holder.iv_Trash2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    delete(comment);
                }

            });

        }

        @Override
        public int getItemCount() {
            return this.comments.size();
        }

        class MyViewHolder extends RecyclerView.ViewHolder {
            TextView tv_CommentName, tv_CommentDesc, tv_CommentDate;
            ImageView iv_Trash2;


            public MyViewHolder(@NonNull View itemView) {
                super(itemView);

                tv_CommentName = itemView.findViewById(R.id.tv_CommentName);
                tv_CommentDesc = itemView.findViewById(R.id.tv_CommentStuff);
                tv_CommentDate = itemView.findViewById(R.id.tv_CommentDate);

                iv_Trash2 = itemView.findViewById(R.id.iv_Trash2);
            }
        }
    }
}