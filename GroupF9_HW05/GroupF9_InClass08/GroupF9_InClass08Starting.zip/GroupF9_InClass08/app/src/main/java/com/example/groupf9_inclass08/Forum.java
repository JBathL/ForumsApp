package com.example.groupf9_inclass08;

public class Forum {
    String forumTitle, name, post;
    int date;

    @Override
    public String toString() {
        return "Forum{" +
                "forumTitle='" + forumTitle + '\'' +
                ", name='" + name + '\'' +
                ", post='" + post + '\'' +
                ", date=" + date +
                '}';
    }

    public Forum() {
    }

    public Forum(String forumTitle, String name, String post, int date) {
        this.forumTitle = forumTitle;
        this.name = name;
        this.post = post;
        this.date = date;
    }

    public String getForumTitle() {
        return forumTitle;
    }

    public void setForumTitle(String forumTitle) {
        this.forumTitle = forumTitle;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }
}
